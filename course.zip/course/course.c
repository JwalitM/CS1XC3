/**
 * @file course.c
 * @author Jwalit Miniwala (you@domain.com)
 * @brief it has the functions which enrolls students, with the courses and then tells the top student of the course along with students who are passing
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief enrolling the student along with their course
 * 
 * @param course course of the students
 * @param student students who are getting enrolled
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // calloc() is allocating memory
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief it is printing the name, code and total students in the course
 * 
 * @param course it is the course detail of the students
 */
void print_course(Course* course)
{
  // printing the course detail which includes the name, code and total students in it.
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief it is checking for the top student in the course with the max average
 * 
 * @param course it is the course of the students which they have taken
 * @return Student* returns the student who has topped
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  // it is checking for the student with the max average
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief it is returning the array of students who are passing the course
 * 
 * @param course course which students are taking
 * @param total_passing number of student who are passing the course
 * @return Student* returning the array of students who are passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  // checking for the number of students who have the average above 50
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // adding the passing students to an array
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;
  // it is returning the array with the passing students
  return passing;
}