/**
 * @file student.c
 * @author Jwalit Miniwala (you@domain.com)
 * @brief it has the functions which adds grades, gets the average, prints the students name and generates a random student.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief it is adding the grades for the students
 * 
 * @param student student whose grades are being added
 * @param grade grades that will be added
 */
void add_grade(Student* student, double grade)
{
  // increasing the count of the array and calloc() allocates memory for the array
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}
/**
 * @brief it is returning the average grade of students
 * 
 * @param student students whose average will be returned
 * @return double it will return the average
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;
  // it is getting sum of all grades and then getting the average
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}
/**
 * @brief it will be printing the first and last names of the student along with their ID, their grades and their average
 * 
 * @param student this is a parameter for the students whose first and last name will be printed
 */
void print_student(Student* student)
{
  // printing the first and last name
  printf("Name: %s %s\n", student->first_name, student->last_name);
  // printing the ID
  printf("ID: %s\n", student->id);
  // printing the Grades
  printf("Grades: ");
  // checking the grades and finding the average
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 * @brief will generate a random student array of 24 students based on the first and last name along with ID and grades
 * 
 * @param grades this are the grades of students which will be returned along with their name
 * @return Student* it will return the random student array based on the grades
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  // calloc() is allocating memory
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}