/**
 * @brief it has the typedef struct of the students with their first name(which cannot exceed 50 characters), last name(which cannot exceed 50 characters), student id, array of the grades and number of grades 
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
